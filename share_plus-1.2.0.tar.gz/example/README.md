# share_example

Demonstrates how to use the share_plus plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
